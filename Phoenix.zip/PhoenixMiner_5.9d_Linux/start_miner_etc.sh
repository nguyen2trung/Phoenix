#
# Example shell file for starting PhoenixMiner.exe to mine ETC
#

# IMPORTANT: Replace the ETC address with your own ETC wallet address in the -wal option (Rig001 is the name of the rig)
./PhoenixMiner -pool ssl://eu1-etc.ethermine.org:5555 -wal 0x360d6f9efea21c82d341504366fd1c2eeea8fa9d.Rig001 -coin etc
